#!/bin/bash

export GCS_OAUTH_TOKEN=`gcloud auth application-default print-access-token`

SAMP=$1
DIR=$2

samtools view -b gs://runs-data/cromwell-execution/JukeboxVC/${DIR}/call-MarkDuplicatesSpark/${SAMP}.aligned.unsorted.duplicates_marked.bam \
| tee -p \
>(picard CollectWgsMetrics \
    R=/data/genomes/broad-references/hg38/v0/Homo_sapiens_assembly38.fasta \
    I=/dev/stdin \
    O=${SAMP}.wgs_metrics.txt \
    MINIMUM_MAPPING_QUALITY=0 MINIMUM_BASE_QUALITY=10 INCLUDE_BQ_HISTOGRAM=true COUNT_UNPAIRED=true READ_LENGTH=200) \
>(picard CollectAlignmentSummaryMetrics \
    R=/data/genomes/broad-references/hg38/v0/Homo_sapiens_assembly38.fasta \
    I=/dev/stdin \
    O=${SAMP}.alignment_summary.txt) \
>(picard CollectQualityYieldMetrics \
    I=/dev/stdin \
    O=${SAMP}.quality_yield_metrics.txt) \
> /dev/null 

